package ru.msu.cmc.sphere;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

import ru.msu.cmc.sphere.Main.*;

public class MainTest {
    @Test
    public void testInput() throws Exception
    {
        Reader reader = new Reader();

        String[] testDataInp = {
                "1 2 3 4",
                "10 10 20 10",
                "9 0 4 1 2 4",
                "0 9 1 2 4 5",
                "5 8 c 9 0 f",
                ""
        };

        Integer[][] testDataOut = {
                {1, 2, 3, 4},
                {10, 10, 20, 10},
                {9, 0, 4, 1, 2, 4},
                {0, 9, 1, 2, 4, 5},
                {5, 8},
                {}
        };

        for (int i = 0; i < testDataInp.length; ++i) {
            List<Integer> actual = reader.getData(new ByteArrayInputStream(testDataInp[i].getBytes(StandardCharsets.UTF_8)));
            assertThat(actual, is(Arrays.asList(testDataOut[i])));
        }
    }

    @Test
    public void testGetArea() throws Exception {
        Integer[][] data = {
                {10, 9, 8, 7, 8, 9, 10},
                {},
                {0},
                {0, 1, 2, 3, 4, 5},
                {5, 4, 3, 2, 1, 0},
                {5, 10, 5, 15, 0, 0, 8, 10, 10, 1, 12},
                {7, 3, 4, 3, 8, 5, 5, 3, 10, 2, 3, 5, 5, 6, 2, 2, 4, 2}
        };

        Integer[] answers = {9, 0, 0, 0, 0, 48, 35};

        for (int i = 0; i < data.length; ++i) {
            assertSame(answers[i], Main.getArea(Arrays.asList(data[i])));
        }

    }
}
